<template>
    <div>

    </div>
</template>
<script>
export default {
  name: '',
  data () {
    return {}
  },
  mounted: function () {
    this.$axios.post('/api/admin/list', {
      page: 1, // 当前页
      pageSize: 3 // 页容量
    },
    {
      headers: {
        'Content-Type': 'application/json'
      }
    }).then((res) => {
      console.log(res.data.data)
    })
  }
}
</script>
<style scope>

</style>
