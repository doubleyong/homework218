/**
 * Created by Administrator on 2020/4/25.
 */
const myespress=require("express");
const favicon=require("serve-favicon");
const bodyParser=require("body-parser");
const cookieParser=require("cookie-parser");
const logger=require("morgan");
const userRouter=require("./router/userRouter");
const app=myespress();
//定义日志
app.use(logger("dev"));
// 配置静态资源
app.use(myespress.static(__dirname+"/public",{index:"login.html"}));
// 定义数据解析器
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));
//定义cookie解析器
app.use(cookieParser());
//加载图标
app.use(favicon(__dirname+"/public/images/icon.png"));
//拦截路由
app.use(userRouter);
app.listen(9994);