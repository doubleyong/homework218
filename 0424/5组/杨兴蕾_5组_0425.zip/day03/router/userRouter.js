/**
 * Created by Administrator on 2020/4/25.
 */
const myexpress=require("express");
const router=myexpress.Router();//设置路由
const db=require("./DBconfig");
//登录
router.post("/login.do",function (request,response) {
    var userName=request.body.txtUser;
    var pwd=request.body.txtPwd;
    // 在数据库中查询是否存在该用户
    let sql="select * from tb_user2 where usename=? and pwd=?";
    db.query(sql,[userName,pwd],function (err,data) {
        if(err){
            console.log(err);
        }else{
            if(data.length==0){
                response.send("<script>alert('用户名或密码错误');history.back();</script>")

            }else{
                response.send("<script>alert('登录成功');location.href='userMange.html'</script>");
            }
        }

    })

});
//注册
router.post("/reg.do",function (request,response) {
    var userName=request.body.txtUser;
    var pwd=request.body.txtPwd;
    let sql="insert into tb_user2(usename,pwd) values (?,?) ";
    db.query(sql,[userName,pwd],function (err,data) {
        if(err){
            console.log(err);
        }else{
            if(data.affectedRows>0){
                response.send("<script>alert('注册成功');location.href='login.html'</script>")
            }else{
                response.send("注册失败");
            }
        }
    })

});
// 显示数据
router.get("/showList.do",function (request,response) {
    let sql="select * from tb_user2";
    db.query(sql,[],function (err,data) {
        response.send(data);
    })

});
// 单个删除数据
router.get("/del.do",function (request,response) {
    var id=request.query.uid;
    let sql="delete from tb_user2 where id=?";
    db.query(sql,[id],function (err,data) {
        if(err){
           response.send("有错，请联系管理员") ;
        }else if(data.affectedRows>0){
            response.send("删除成功");
        }else{
            response.send("删除失败");
        }
    })
});
// 查询
router.post("/search.do",function (request,response) {
    var user=request.body.user;
    var sex=request.body.sex;
    var currentPage=request.body.currentPage;
    var pageSize=request.body.pageSize;
    var param=[];
    let sql="select * from tb_user where 1=1";
    if(user.trim()!=""){
        sql+=" and username like ?";
        user="%"+user+"%";//模糊查询的写法
        param.push(user)
    }
    if(sex!=-1){
        sql+=" and sex = ?";
        param.push(sex);
    }
    sql+= " limit ?,?";
    let start=(currentPage-1)*Number(pageSize);
    let ends=Number(pageSize);
    param.push(start,ends);
    db.query(sql,param,function (err,data) {
        console.log(err);
        console.log( data);
        response.send(data);
    })

});
// 添加数据
router.post("/addData.do",function (request,response) {
    // 接收数据
    var user=request.body.txtUser;
    var pwd=request.body.txtPwd;

    //数据操作
    let sql="insert into tb_user2(usename,pwd) values(?,?)";
    db.query(sql,[user,pwd],function (err,data) {
        console.log(err);
        console.log(data);
        if(err){
            console.log(err);
            response.send("添加有错，请联系管理员")
        }else{
            if(data.affectedRows>0){
                response.send("添加成功");
            }else{
                response.send("添加失败");
            }
        }
    });
});
//查询总条数
router.post("/totalCount.do",function (request,response) {
    let sql="select count(*) as num from tb_user2";
    db.query(sql,[],function (err,data) {
        response.send(data);//count返回单行单列
    })
});
//公开访问此模块
module.exports=router;