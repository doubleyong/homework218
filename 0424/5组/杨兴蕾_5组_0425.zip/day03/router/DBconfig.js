/**
 * Created by Administrator on 2020/4/25.
 */
const mysql=require("mysql");
function DBoper(sql,param,callback) {
    // 创建连接
    let myConnect=mysql.createConnection({
        host:"localhost",
        user:"root",
        password:"YXL757597",
        port:3306,//默认是3306可以不写
        database:"w218_1"
    });
    // 打开连接
    myConnect.connect();
    // 数据库操作
    myConnect.query(sql,param,callback);
    // 关闭链接
    myConnect.end();
}
module.exports={
    query:DBoper
};