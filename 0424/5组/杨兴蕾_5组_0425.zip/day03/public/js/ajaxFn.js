/**
 * Created by Administrator on 2020/4/22.
 */
function ajax(method,url,sycn,callback,param) {
    // 创建对象
    var xmlHttp;
    if(window.XMLHttpRequest){
        xmlHttp=new XMLHttpRequest();
    }else if(window.ActiveXObject){
        xmlHttp=new ActiveXObject("Microsoft.XMLHttp");
    }
    // 设置请求
    if(method.toLowerCase()=="get"){
        url=url+"?"+param;
    }
    xmlHttp.open(method,url,sycn,callback,param);
    // 接收响应回来的数据
    xmlHttp.onreadystatechange=function () {
        if(xmlHttp.status==200&&xmlHttp.readyState==4){
            callback(xmlHttp.responseText)
        }
    };
    // 发起请求
    if(method.toLowerCase=="post"){
        xmlHttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");//设置请求头
        xmlHttp.send(param)
    }else{
        xmlHttp.send(null);
    }

}